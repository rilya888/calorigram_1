"""
Модуль для валидации данных
"""
from typing import Tuple, Optional
from logging_config import get_logger
from constants import MIN_AGE, MAX_AGE, MIN_HEIGHT, MAX_HEIGHT, MIN_WEIGHT, MAX_WEIGHT, ACTIVITY_LEVELS, GENDERS
from utils import validate_telegram_id

logger = get_logger(__name__)

class DataValidator:
    """Класс для валидации различных типов данных"""
    
    @staticmethod
    def validate_user_input(telegram_id: int, name: str, gender: str, age: int, 
                           height: float, weight: float, activity_level: str) -> Tuple[bool, str]:
        """Валидирует входные данные пользователя"""
        try:
            # Проверяем telegram_id
            if not validate_telegram_id(telegram_id):
                return False, "Неверный Telegram ID"
            
            # Проверяем имя
            if not name or len(name.strip()) < 2 or len(name.strip()) > 50:
                return False, "Имя должно содержать от 2 до 50 символов"
            
            # Проверяем пол
            if gender not in GENDERS:
                return False, "Неверный пол"
            
            # Проверяем возраст
            if not isinstance(age, int) or age < MIN_AGE or age > MAX_AGE:
                return False, f"Возраст должен быть от {MIN_AGE} до {MAX_AGE} лет"
            
            # Проверяем рост
            if not isinstance(height, (int, float)) or height < MIN_HEIGHT or height > MAX_HEIGHT:
                return False, f"Рост должен быть от {MIN_HEIGHT} до {MAX_HEIGHT} см"
            
            # Проверяем вес
            if not isinstance(weight, (int, float)) or weight < MIN_WEIGHT or weight > MAX_WEIGHT:
                return False, f"Вес должен быть от {MIN_WEIGHT} до {MAX_WEIGHT} кг"
            
            # Проверяем уровень активности
            if activity_level not in ACTIVITY_LEVELS:
                return False, "Неверный уровень активности"
            
            return True, "OK"
            
        except Exception as e:
            logger.error(f"Error validating user input: {e}")
            return False, "Ошибка валидации данных"
    
    @staticmethod
    def validate_meal_data(meal_type: str, meal_name: str, calories: int) -> Tuple[bool, str]:
        """Валидирует данные о приеме пищи"""
        try:
            # Проверяем тип приема пищи
            valid_meal_types = ['meal_breakfast', 'meal_lunch', 'meal_dinner', 'meal_snack']
            if meal_type not in valid_meal_types:
                return False, "Неверный тип приема пищи"
            
            # Проверяем название блюда
            if not meal_name or len(meal_name.strip()) < 2 or len(meal_name.strip()) > 100:
                return False, "Название блюда должно содержать от 2 до 100 символов"
            
            # Проверяем калории
            if not isinstance(calories, int) or calories < 0 or calories > 10000:
                return False, "Калории должны быть от 0 до 10000"
            
            return True, "OK"
            
        except Exception as e:
            logger.error(f"Error validating meal data: {e}")
            return False, "Ошибка валидации данных о приеме пищи"
    
    @staticmethod
    def validate_file_size(file_data: bytes, file_type: str, max_size: int) -> Tuple[bool, str]:
        """Валидирует размер файла"""
        try:
            if not file_data:
                return False, "Пустые данные файла"
            
            if len(file_data) > max_size:
                size_mb = max_size // (1024 * 1024)
                return False, f"Файл слишком большой (максимум {size_mb}MB)"
            
            if len(file_data) < 100:
                return False, "Файл слишком маленький, возможно поврежден"
            
            return True, "OK"
            
        except Exception as e:
            logger.error(f"Error validating file size: {e}")
            return False, "Ошибка валидации файла"
    
    @staticmethod
    def validate_text_input(text: str, min_length: int = 10, max_length: int = 1000) -> Tuple[bool, str]:
        """Валидирует текстовый ввод"""
        try:
            if not text:
                return False, "Пустой текст"
            
            clean_text = text.strip()
            if len(clean_text) < min_length:
                return False, f"Текст слишком короткий (минимум {min_length} символов)"
            
            if len(clean_text) > max_length:
                return False, f"Текст слишком длинный (максимум {max_length} символов)"
            
            return True, "OK"
            
        except Exception as e:
            logger.error(f"Error validating text input: {e}")
            return False, "Ошибка валидации текста"

# Глобальный экземпляр валидатора
validator = DataValidator()
